# How to run
>> Go into HW1 directory

## Run flips
>> make flips

## Run resolution
>> make resolution

## Run crops
>> make crop